# Curie ESP32 Firmware Bundle

This bundle contains two separate firmware images:

- `robot\curie_robot_full_4mb.bin`
  - for the robot ESP32
- `controller\curie_controller_full_4mb.bin`
  - for the handheld controller ESP32

Both targets are for:

- ESP32 DevKit V1
- 30-pin boards
- 4 MB flash

## What the robot firmware does

- boots AP-first every time
- creates Wi-Fi SSID: `Infrared Curie Setup`
- AP IP: `192.168.4.1`
- serves the dashboard at:
  - `http://192.168.4.1`
- keeps AP active while Wi-Fi credentials are added from the dashboard
- supports:
  - dashboard
  - WebSocket control
  - OTA endpoint
  - expressions
  - movement
  - shoulder control
  - delayed ESP-NOW controller receiver

## What the controller firmware does

- uses ESP-NOW, not Wi-Fi client mode
- expects the robot to run on channel `1`
- control layout:
  - keypad = expressions
  - left joystick = drive
  - diamond buttons = shoulders/home/estop
  - joystick press = speed mode / clear estop

Controller pinout reference:

- [CONTROLLER_PINOUT.md](</C:/Users/ameri/Documents/New project/Infrared-Curie-Repo/docs/CONTROLLER_PINOUT.md>)

## What I verified

- Robot firmware:
  - source build succeeded
  - merged full-flash image generated
- Controller firmware:
  - source build succeeded
  - merged full-flash image generated

## What I could not fully verify in this bundle

- I did not flash these final images from this machine because the local serial port was not in a usable state at packaging time.
- That means the deliverable is build-verified, not final-hardware-verified on this PC.

## Fastest flash method on Windows

Install esptool:

```bat
py -m pip install esptool
```

Then use the provided scripts:

- `flash_robot_windows.bat COMx`
- `flash_controller_windows.bat COMy`

Example:

```bat
flash_robot_windows.bat COM5
flash_controller_windows.bat COM6
```

If no COM port is passed, each script defaults to `COM5`.

## Direct Windows commands

### Robot

```bat
py -m esptool --chip esp32 -p COM5 -b 115200 --before default_reset --after hard_reset write_flash 0x0 robot\curie_robot_full_4mb.bin
```

### Controller

```bat
py -m esptool --chip esp32 -p COM6 -b 115200 --before default_reset --after hard_reset write_flash 0x0 controller\curie_controller_full_4mb.bin
```

## macOS / Linux

Install esptool:

```bash
python3 -m pip install esptool
```

Then run:

```bash
chmod +x flash_robot_mac_linux.sh flash_controller_mac_linux.sh
./flash_robot_mac_linux.sh /dev/ttyUSB0
./flash_controller_mac_linux.sh /dev/ttyUSB1
```

## After flashing the robot

1. Power the robot ESP32.
2. Connect phone or laptop to:
   - `Infrared Curie Setup`
3. Open:
   - `http://192.168.4.1`
4. Use the dashboard.
5. If needed, add the local Wi-Fi from the dashboard.

## After flashing the controller

1. Power the controller ESP32.
2. It will start sending ESP-NOW commands on channel `1`.
3. The robot must already be running the robot firmware above.

## Individual component binaries

These are included for manual flashing if needed:

### Robot

- `robot\bootloader.bin`
- `robot\partition-table.bin`
- `robot\ota_data_initial.bin`
- `robot\curie_robot_app.bin`

### Controller

- `controller\bootloader.bin`
- `controller\partitions.bin`
- `controller\curie_controller_app.bin`
